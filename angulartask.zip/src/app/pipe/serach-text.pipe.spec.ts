import { SerachTextPipe } from './serach-text.pipe';

describe('SerachTextPipe', () => {
  it('create an instance', () => {
    const pipe = new SerachTextPipe();
    expect(pipe).toBeTruthy();
  });
});
