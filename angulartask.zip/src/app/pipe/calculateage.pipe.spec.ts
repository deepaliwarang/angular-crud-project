import { CalculateagePipe } from './calculateage.pipe';

describe('CalculateagePipe', () => {
  it('create an instance', () => {
    const pipe = new CalculateagePipe();
    expect(pipe).toBeTruthy();
  });
});
